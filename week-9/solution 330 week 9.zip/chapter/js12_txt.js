"use strict";

/*  JavaScript 7th Edition
    Chapter 12
    Chapter case

    Bonsai Expressions FAQ 
    Author: Nadia Gainer
    Date:   5/19/24

    Filename: js12.js
*/

